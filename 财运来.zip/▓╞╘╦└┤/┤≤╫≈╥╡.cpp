#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <math.h> 
#include <windows.h> 
#define LENTH 25
#define LEN sizeof(struct stockinf)
using namespace std;
void HideCursor();  
void Gotoxy(int x, int y); 
void DrawBox(); 
int wherex();
int wherey();
struct stockinf {
	int number;
	int date[3];
	int datenum; 
	double open;
	double high;
	double low;
	double close;
	double aclose;
	double volume;
	char code1[7];
	char code2[3]; 
	double range;
	double EMA_12;
	double EMA_26;
	double DIF;
	double DEA;
	double MACD; 
};
long long int n=-1;
long long int num;
struct stockinf *use;
char mmm[1000];
double a;
int i;
int lan=0;
struct cross{
	int goldencross;
	int deadcross;
	char code1[7];
	char code2[3];
};
struct cross*mmp;
int LoadStockData(char *filename) {
	FILE *fp;
	if ((fp = fopen(filename, "r")) == NULL) {
		printf("cannot open infile :%s\n", filename);
		return -1;
	}
	DrawBox();
	while (!feof(fp)) {
		fgets(mmm,1000,fp); 
		n = n + 1;}
	    use = (struct stockinf *)malloc(n*LEN);
	    num=n-1; 
	    n=-1;
		rewind(fp);
		int len=0;
		double goup;
		//HideCursor(); 
		int x=wherex();
		int y=wherey();
	while(!feof(fp)){
		goup=(double)(n+1)/num*25.0;
		if(fabs(goup-len)<25.0/num) {
			Gotoxy(2 * len+2, y-2 ); 
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
			printf("��");
			Gotoxy(21, y); 
			if(lan==2)
			printf("�����%d%%", 4 * len); 
			else 
			printf("completed%d%%", 4 * len); 
			len++; 
		}
		n = n + 1;
        if (n == 0){
		fgets(mmm, 1000, fp);
	}
		else {
			use[n].volume=0;
			fscanf(fp, "%d-%d-%d,%lf,%lf,%lf,%lf,%lf,%lf,", &use[n].date[0], &use[n].date[1], &use[n].date[2], &use[n].open, &use[n].high, &use[n].low, &use[n].close, &use[n].aclose, &use[n].volume);
			use[n].datenum = use[n].date[0] * 10000 + use[n].date[1] * 100 + use[n].date[2];
			if (use[n].open != 0.0)
				fscanf(fp, "%c%c%c%c%c%c.%c%c", &use[n].code1[0], &use[n].code1[1], &use[n].code1[2], &use[n].code1[3], &use[n].code1[4], &use[n].code1[5], &use[n].code2[0], &use[n].code2[1]);
			else
			{
				fscanf(fp, "%c%c%c%c%c%c", &mmm[0], &mmm[1], &mmm[2], &mmm[3], &mmm[4], &mmm[5]);
				fscanf(fp, "%c%c%c%c%c%c.%c%c", &use[n].code1[0], &use[n].code1[1], &use[n].code1[2], &use[n].code1[3], &use[n].code1[4], &use[n].code1[5], &use[n].code2[0], &use[n].code2[1]);
				use[n].open =use[n].high = use[n].low = use[n].close = use[n].aclose = a;
			}
			a = use[n].aclose;
		    //cout<<n<<"��"<<use[n].date[0]<<"-"<<use[n].date[1]<<"-"<<use[n].date[2]<<" "<<use[n].open<<" "<<use[n].high<<" "<<use[n].low<<" "<<use[n].close<<" "<<use[n].aclose<<" "<<use[n].volume<<" "<<use[n].code1<<"."<<use[n].code2<<endl;
			fscanf(fp, "%s", mmm);
			use[n].EMA_12=use[n].EMA_26=use[n].DIF=use[n].DEA=use[n].MACD=0.0;
			use[n].number=n;
		}
	}
	Gotoxy(21, y);  
	if(lan==2)
	printf("���ݼ��������\n");
	else
	printf("Data loading completed\n");
	n--;
	fclose(fp);
	return n;}

//���ع�꣬ͷ�ļ�
void HideCursor() 
{ 
 
CONSOLE_CURSOR_INFO cursor_info = {1, 0}; 
//��ߵ�0������겻�ɼ�
 
 
SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info); 
} 
  
//����ƶ���ͷ�ļ�
void Gotoxy(int x, int y) 
{ 
 
HANDLE hout; //����������hout 
 
COORD coord; //����ṹ��coord 
 
coord.X = x; 
  
coord.Y = y;  
 
hout = GetStdHandle(STD_OUTPUT_HANDLE); 
 
//��ñ�׼�������Ļ�����
 
 
SetConsoleCursorPosition(hout, coord); 
 
//�ƶ����
 
} 
  
//���߿�ͷ�ļ�
void DrawBox() 
{ 
SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
printf("�X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�["); 
 
putchar('\n'); 
 
printf("�U                                                    �U"); 
 
putchar('\n'); 
 
printf("�^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a");  
}  
int cmpstd2(const void*p1, const void*p2){//��Ʊ�������� 
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if (strcmp(a->code2, b->code2) < 0 || (strcmp(a->code1, b->code1) > 0 && strcmp(a->code2, b->code2) == 0)
		|| (strcmp(a->code2, b->code2) == 0 && strcmp(a->code1, b->code1) == 0 && a->datenum > b->datenum)) {
		return 1;
	}
	else if (a->datenum == b->datenum&&strcmp(a->code2, b->code2) == 0 && strcmp(a->code1, b->code1) == 0)
		return 0;
	else return -1;}
int cmpstd1(const void*p1, const void*p2) {
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if (a->datenum>b->datenum || (a->datenum == b->datenum&&strcmp(a->code2, b->code2)<0)
		|| (a->datenum == b->datenum&&strcmp(a->code2, b->code2) == 0 && strcmp(a->code1, b->code1)>0)) {
		return 1;
	}
	else if (a->datenum == b->datenum&&strcmp(a->code2, b->code2) == 0 && strcmp(a->code1, b->code1) == 0)
		return 0;
	else return -1;
}
int cmpstd3(struct stockinf a,struct stockinf b){
	if(a.datenum>b.datenum) return 1;
	else if(a.datenum<b.datenum) return -1;
	else {
		return strcmp(a.code1,b.code1);
	}
}
int bisearch(stockinf use[], int low,int high,stockinf key) {
  if (low > high)	  //û�ҵ�
    return -1;
  int mid = (low + high) / 2;
  if (cmpstd3(key,use[mid])==0)  //�ҵ�
    return mid;
  else if (cmpstd3(key,use[mid])<0)  //������
	return bisearch(use, low, mid - 1, key);
  else	//���Ұ��
	return bisearch(use, mid + 1, high, key);
}
int Query(char * para_str) {
	int i, j;
	int r=0;
	int count1 = 0;
	char c = '\0';
	char order[7];
	stockinf key;
	stockinf *p = &key;
	for (i = 0; para_str[i] != '\0'; i++) {
		if (para_str[i] == 'C') {
			order[count1] = para_str[i];
			count1++;
			for (j = 0; j < 6; j++) {
				key.code1[j] = para_str[i + j + 2];
			}
			key.code1[6]='\0';
			key.code2[0] = para_str[i + 9];
			key.code2[1] = para_str[i + 10];//����ҪѰ�ҵĹ�Ʊ����//
			key.code2[2]='\0';
		}
		else if (para_str[i] == 'd') {
			order[count1] = para_str[i];
			count1++;
			key.date[0] = 1000 * (para_str[i + 2] - '0') + 100 * (para_str[i + 3] - '0') + 10 * (para_str[i + 4] - '0') + (para_str[i + 5] - '0');//����ҪѰ�ҵ�����//
			key.date[1] = 10 * (para_str[i + 7] - '0') + (para_str[i + 8] - '0');
			key.date[2] = 10 * (para_str[i + 10] - '0') + (para_str[i + 11] - '0');
			key.datenum=key.date[0]*10000+key.date[1]*100+key.date[2];
		}

		else if (para_str[i] == 'o' || para_str[i] == 'c' || para_str[i] == 'a' || para_str[i] == 'h' || para_str[i] == 'l') {
			order[count1] = para_str[i];
			count1++;
		}
	}//�������������//
	for (i = 0; i < count1; i++) {
		if (order[i] == 'C'&&i != 0) {
			c = order[i];
			for (j = i - 1; j >= 0; j--) {
				order[j + 1] = order[j];
			}
			order[0] = c;
		}}//��code�������˳���Ƶ�ǰ��// 
	for (i = 0; i < count1; i++) {
		if (order[i] == 'd'&&i != 1) {
			c = order[i];
			for (j = i - 1; j >= 1; j--) {
				order[j + 1] = order[j];
			}
			order[1] = c;
		}
	}//��date�������˳���Ƶ�ǰ��//
	qsort(use+1, num, sizeof(use[1]), cmpstd1);
	r=bisearch(use,1,num,key);//����ֵr// 
	if(r!=-1) {
		for (j = 0; j < count1; j++) {
		if (order[j] == 'C') printf("%s.%s ", key.code1, key.code2);
		if (order[j] == 'd') printf("%d-%.02d-%.02d ", key.date[0], key.date[1], key.date[2]);
		if (order[j] == 'o') printf("-o %f ", use[r].open);
		if (order[j] == 'c') printf("-c %f ", use[r].aclose);
		if (order[j] == 'a') printf("-a %f ", use[r].aclose);
		if (order[j] == 'h') printf("-h %f ", use[r].high);
		if (order[j] == 'l') printf("-l %f ", use[r].low);
		}
		return 0;
	}
	else return -1;
}
int Comp1(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
		if(a->volume>b->volume||(a->volume==b->volume&&strcmp(a->code1,b->code1)>0)||(a->volume==b->volume&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)>0)) return 1;
	    else if(a->volume<b->volume||(a->volume==b->volume&&strcmp(a->code1,b->code1)<0)||(a->volume==b->volume&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)<0)) return -1;
}
int Comp2(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if(a->aclose>b->aclose||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)>0)||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)>0)) return 1;
	else if(a->aclose<b->aclose||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)<0)||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)<0)) return -1;
}
int Comp3(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if(a->range>b->range||(a->range==b->range&&strcmp(a->code1,b->code1)>0)||(a->range==b->range&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)>0)) return 1;
	else if(a->range<b->range||(a->range==b->range&&strcmp(a->code1,b->code1)<0)||(a->range==b->range&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)<0)) return -1;
}
int Comp4(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
		if(a->volume>b->volume||(a->volume==b->volume&&strcmp(a->code1,b->code1)<0)||(a->volume==b->volume&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)<0)) return 1;
	    else if(a->volume<b->volume||(a->volume==b->volume&&strcmp(a->code1,b->code1)>0)||(a->volume==b->volume&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)>0)) return -1;
}
int Comp5(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if(a->aclose>b->aclose||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)<0)||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)<0)) return 1;
	else if(a->aclose<b->aclose||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)>0)||(a->aclose==b->aclose&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)>0)) return -1;
}
int Comp6(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if(a->range>b->range||(a->range==b->range&&strcmp(a->code1,b->code1)<0)||(a->range==b->range&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)<0)) return 1;
	else if(a->range<b->range||(a->range==b->range&&strcmp(a->code1,b->code1)>0)||(a->range==b->range&&strcmp(a->code1,b->code1)==0&&strcmp(a->code2,b->code2)>0)) return -1;
}
int TopK(char *date, char *data, int k, int desc)
{
	struct stockinf select[8000];
	char v[7]="Volume";
	char a[9]="AdjClose";
	char r[6]="Range";
	int datenum1,whether=0,i=0,j=0;
	datenum1=(date[0]-'0')*10000000+(date[1]-'0')*1000000+(date[2]-'0')*100000+(date[3]-'0')*10000+(date[5]-'0')*1000+(date[6]-'0')*100+(date[8]-'0')*10+(date[9]-'0');
	for(i=1;i<=n;i++)
	{
		if(use[i].datenum==datenum1)
		{
			select[j]=use[i];
			j++;
			whether=1;
		}
	}
	for(i=0;i<j;i++) 
	{
		select[i].range=(select[i].high-select[i].low)/select[i].open*100;
	}
	if(whether==0) return -1;
	if(desc==0) 
	{
		if(strcmp(data,v)==0) qsort(select,j,sizeof(select[1]),Comp1);
	else if(strcmp(data,a)==0) qsort(select,j,sizeof(select[1]),Comp2);
	else if(strcmp(data,r)==0) qsort(select,j,sizeof(select[1]),Comp3);
		for(i=0;i<k;i++)
		{
			printf("%s.%s %s %.2f %.2f %.6f %.2f%% %.0f\n",select[i].code1,select[i].code2,date,select[i].open,select[i].close,select[i].aclose,select[i].range,select[i].volume);
		}
	}
	else
	{
		if(strcmp(data,v)==0) qsort(select,j,sizeof(select[1]),Comp4);
	else if(strcmp(data,a)==0) qsort(select,j,sizeof(select[1]),Comp5);
	else if(strcmp(data,r)==0) qsort(select,j,sizeof(select[1]),Comp6);
		for(i=j-1;i>j-1-k;i--)
		{
			printf("%s.%s %s %.2f %.2f %.6f %.2f%% %.0f\n",select[i].code1,select[i].code2,date,select[i].open,select[i].close,select[i].aclose,select[i].range,select[i].volume);
		}
	}
	return(j);
}

double Calculate(char *para_str){
    char CODE1[7];
    char CODE2[3]={'\0','\0','\0'};
    int i=0;
    //���ַ����е���Ϣ����� 
    for(int i=0;i<6;i++){
    	CODE1[i]=*(para_str+i+3);
	}
	for(int i=0;i<2;i++){
		CODE2[i]=*(para_str+10+i);
	}
	int sdate=(*(para_str+16)-'0')*10000000+(*(para_str+17)-'0')*1000000+(*(para_str+18)-'0')*100000+(*(para_str+19)-'0')*10000+(*(para_str+21)-'0')*1000+
	(*(para_str+22)-'0')*100+(*(para_str+24)-'0')*10+(*(para_str+25)-'0');
    int fdate=(*(para_str+30)-'0')*10000000+(*(para_str+31)-'0')*1000000+(*(para_str+32)-'0')*100000+(*(para_str+33)-'0')*10000+(*(para_str+35)-'0')*1000+
    (*(para_str+36)-'0')*100+(*(para_str+38)-'0')*10+(*(para_str+39)-'0');
	//����Ͳ��� 
	qsort(use+1,num,LEN,cmpstd2);
	struct stockinf key1;
	key1.datenum=sdate;
	strcpy(key1.code1,CODE1);
	strcpy(key1.code2,CODE2);
	struct stockinf *p=&key1;
	struct stockinf *s=(struct stockinf*)bsearch(p,use+1,n,sizeof(use[1]),cmpstd2);
	if(s==NULL) {
		cout<<"-1\n";
		return -1;
	}
	int start=s-use; 
	struct stockinf key2;
	key1.datenum=fdate;
	strcpy(key2.code1,CODE1);
	strcpy(key2.code2,CODE2);
	struct stockinf *p_=&key1;
	struct stockinf *s_=(struct stockinf*)bsearch(p_,use+1,n,sizeof(use[1]),cmpstd2);
	if(s_==NULL) {
		cout<<"-1\n";
		return -1;
	}
	int finish=s_-use; 
	if(finish<start){
		cout<<"-1\n";
		return -1;
	}
	//�������ͳ��ָ�� 
	double open_av=0,open_s=0;
	double close_av=0,close_s=0;
	double high_av=0,high_s=0;
	double low_av=0,low_s=0;
	if(*(para_str+42)=='o'){
	for(int i=start;i<=finish;i++){
		open_av+=use[i].open;
	}
	open_av=open_av/(finish-start+1);
	for(int i=start;i<=finish;i++){
		open_s+=(use[i].open-open_av)*(use[i].open-open_av);
	}
	open_s=sqrt(open_s/(finish-start+1));
	if(*(para_str+45)=='v'){
	printf("%.4lf\n",open_av);
	return open_av;}
	else {
	printf("%.4lf\n",open_s);
	return open_s;}
	}
	if(*(para_str+42)=='c'){
	for(int i=start;i<=finish;i++){
		close_av+=use[i].close;
	}
	close_av=close_av/(finish-start+1);
	for(int i=start;i<=finish;i++){
		close_s+=(use[i].close-close_av)*(use[i].close-close_av);
	}
	close_s=sqrt(close_s/(finish-start+1));
	if(*(para_str+45)=='v'){
		printf("%.4lf\n",close_av);
	return close_av;}
	else {
		printf("%.4lf\n",close_s);
	return close_s;}
	}
	if(*(para_str+42)=='h'){
	for(int i=start;i<=finish;i++){
		high_av+=use[i].high;
	}
	high_av=high_av/(finish-start+1);
	for(int i=start;i<=finish;i++){
		high_s+=(use[i].high-high_av)*(use[i].high-high_av);
	}
	high_s=sqrt(high_s/(finish-start+1));
	if(*(para_str+45)=='v'){
		printf("%.4lf\n",high_av);
	return high_av;}
	else{
		printf("%.4lf\n",high_s);
	return high_s;}
	}
	if(*(para_str+42)=='l'){
	for(int i=start;i<=finish;i++){
		low_av+=use[i].low;
	}
	low_av=low_av/(finish-start+1);
	for(int i=start;i<=finish;i++){
		low_s+=(use[i].low-low_av)*(use[i].low-low_av);
	}
	low_s=sqrt(low_s/(finish-start+1));
	if(*(para_str+45)=='v'){
		printf("%.4lf\n",low_av);
	return low_av;}
	else 
	{printf("%.4lf\n",low_s);
		return low_s;}
	}
} 
void CalcMacd(char *code, char *start_date, char *end_date) {
	int i = 0;
	stockinf start, end;
	stockinf *p = &start;
	stockinf *q = &end;
	stockinf *s = NULL, *e = NULL;
	for (i = 0; i < 6; i++) {
		start.code1[i]=*(code + i);
		end.code1[i] = *(code + i);
	}
	start.code1[6]='\0';
	end.code1[6] = '\0';
	start.code2[0] = *(code + 7);
	start.code2[1] = *(code + 8);
	start.code2[2] = '\0';
	end.code2[0] = *(code + 7);
	end.code2[1] = *(code + 8);
	end.code2[2] = '\0';
	
	start.datenum = (*(start_date)-'0') * 10000000 + (*(start_date + 1) - '0') * 1000000 
		+ (*(start_date + 2) - '0') * 100000 + (*(start_date + 3) - '0') * 10000
		+ (*(start_date + 5) - '0') * 1000 + (*(start_date + 6) - '0') * 100 
		+ (*(start_date + 8) - '0') * 10 + (*(start_date + 9) - '0');
	end.datenum = (*(end_date)-'0') * 10000000 + (*(end_date + 1) - '0') * 1000000
		+ (*(end_date + 2) - '0') * 100000 + (*(end_date + 3) - '0') * 10000
		+ (*(end_date + 5) - '0') * 1000 + (*(end_date + 6) - '0') * 100
		+ (*(end_date + 8) - '0') * 10 + (*(end_date + 9) - '0');
	/*printf("%s.%s ",start.code1, start.code2);
	printf("%d %d\n", start.datenum, end.datenum);*/
	//���ݶ��벢ת��
	qsort(use+1, num, sizeof(use[1]), cmpstd2);
	s = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd2);
	while(s==NULL){
		start.datenum++;
		s = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd2);
		if(s==NULL&&e==NULL&&start.datenum==end.datenum){
	    printf("-1\n");
	    return;
	    }
	}
	e = (stockinf*)bsearch(q, use+1, num, sizeof(use[1]), cmpstd2);
	while(e==NULL){
		end.datenum--;
		e = (stockinf*)bsearch(q, use+1, num, sizeof(use[1]), cmpstd2);
		if(s==NULL&&e==NULL&&start.datenum==end.datenum){
	    printf("-1\n");
	    return;
	    }
	}
	if(s->number<=30) {
		printf("-1\n");
		return ;
	}
	for (i = -30; ((s + i)->datenum) <= (e->datenum); i++) {
		if (i == -30) {
			((s + i)->EMA_12) = ((s + i)->close);
			((s + i)->EMA_26) = ((s + i)->close);
			(s + i)->DIF = 0.0;
			(s + i)->DEA = 0.0;
			(s + i)->MACD = 0.0;
		}
		else {
			((s + i)->EMA_12) = ((s + i)->close) * 2 / 13 + ((s + i - 1)->EMA_12) * 11 / 13;
			((s + i)->EMA_26) = ((s + i)->close) * 2 / 27 + ((s + i - 1)->EMA_26) * 25 / 27;
			((s + i)->DIF)=((s + i)->EMA_12) - ((s + i)->EMA_26);
			((s + i)->DEA) = ((s + i - 1)->DEA)* 0.8 + ((s + i)->DIF) * 0.2;
			((s + i)->MACD) = 2 * (((s + i)->DIF) - ((s + i)->DEA));
		}
		if (i >= 0) {
			printf("%s.%s ", (s + i)->code1, (s + i)->code2);
			printf("%d-%.02d-%.02d ", (s + i)->date[0],(s + i)->date[1],(s + i)->date[2]);
			printf("%.2lf ", (s + i)->close);
			printf("%.0lf ", (s + i)->volume);
			printf("%.4lf ", (s + i)->EMA_12);
			printf("%.4lf ", (s + i)->EMA_26);
			printf("%.4lf ", (s + i)->DIF);
			printf("%.4lf ", (s + i)->DEA);
			printf("%.4lf\n", (s + i)->MACD);
		}	
	}
}
void CalcMacd_without_output(char *code, char *start_date, char *end_date) {
	int i = 0;
	stockinf start, end;
	stockinf *p = &start;
	stockinf *q = &end;
	stockinf *s = NULL, *e = NULL;
	for (i = 0; i < 6; i++) {
		start.code1[i]=*(code + i);
		end.code1[i] = *(code + i);
	}
	start.code1[6]='\0';
	end.code1[6] = '\0';
	start.code2[0] = *(code + 7);
	start.code2[1] = *(code + 8);
	start.code2[2] = '\0';
	end.code2[0] = *(code + 7);
	end.code2[1] = *(code + 8);
	end.code2[2] = '\0';
	
	start.datenum = (*(start_date)-'0') * 10000000 + (*(start_date + 1) - '0') * 1000000 
		+ (*(start_date + 2) - '0') * 100000 + (*(start_date + 3) - '0') * 10000
		+ (*(start_date + 5) - '0') * 1000 + (*(start_date + 6) - '0') * 100 
		+ (*(start_date + 8) - '0') * 10 + (*(start_date + 9) - '0');
	end.datenum = (*(end_date)-'0') * 10000000 + (*(end_date + 1) - '0') * 1000000
		+ (*(end_date + 2) - '0') * 100000 + (*(end_date + 3) - '0') * 10000
		+ (*(end_date + 5) - '0') * 1000 + (*(end_date + 6) - '0') * 100
		+ (*(end_date + 8) - '0') * 10 + (*(end_date + 9) - '0');
	/*printf("%s.%s ",start.code1, start.code2);
	printf("%d %d\n", start.datenum, end.datenum);*/
	//���ݶ��벢ת��
	qsort(use+1, num, sizeof(use[1]), cmpstd2);
	s = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd2);
	while(s==NULL){
		start.datenum++;
		s = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd2);
		if(s==NULL&&e==NULL&&start.datenum==end.datenum){
	//   printf("-1");
	    return;
	    }
	}
	e = (stockinf*)bsearch(q, use+1, num, sizeof(use[1]), cmpstd2);
	while(e==NULL){
		end.datenum--;
		e = (stockinf*)bsearch(q, use+1, num, sizeof(use[1]), cmpstd2);
		if(s==NULL&&e==NULL&&start.datenum==end.datenum){
	//    printf("-1");
	    return;
	    }
	}
	if(s->number<=30) {
		//printf("-1");
		return ;
	}
	for (i = -30; ((s + i)->datenum) <= (e->datenum); i++) {
		if (i == -30) {
			((s + i)->EMA_12) = ((s + i)->close);
			((s + i)->EMA_26) = ((s + i)->close);
			(s + i)->DIF = 0.0;
			(s + i)->DEA = 0.0;
			(s + i)->MACD = 0.0;
		}
		else {
			((s + i)->EMA_12) = ((s + i)->close) * 2 / 13 + ((s + i - 1)->EMA_12) * 11 / 13;
			((s + i)->EMA_26) = ((s + i)->close) * 2 / 27 + ((s + i - 1)->EMA_26) * 25 / 27;
			((s + i)->DIF)=((s + i)->EMA_12) - ((s + i)->EMA_26);
			((s + i)->DEA) = ((s + i - 1)->DEA)* 0.8 + ((s + i)->DIF) * 0.2;
			((s + i)->MACD) = 2 * (((s + i)->DIF) - ((s + i)->DEA));
		}
	}
}
void CalcMacd_without_output_without_qsort(char *code, char *start_date, char *end_date) {
	int i = 0;
	stockinf start, end;
	stockinf *p = &start;
	stockinf *q = &end;
	stockinf *s = NULL, *e = NULL;
	for (i = 0; i < 6; i++) {
		start.code1[i]=*(code + i);
		end.code1[i] = *(code + i);
	}
	start.code1[6]='\0';
	end.code1[6] = '\0';
	start.code2[0] = *(code + 7);
	start.code2[1] = *(code + 8);
	start.code2[2] = '\0';
	end.code2[0] = *(code + 7);
	end.code2[1] = *(code + 8);
	end.code2[2] = '\0';
	
	start.datenum = (*(start_date)-'0') * 10000000 + (*(start_date + 1) - '0') * 1000000 
		+ (*(start_date + 2) - '0') * 100000 + (*(start_date + 3) - '0') * 10000
		+ (*(start_date + 5) - '0') * 1000 + (*(start_date + 6) - '0') * 100 
		+ (*(start_date + 8) - '0') * 10 + (*(start_date + 9) - '0');
	end.datenum = (*(end_date)-'0') * 10000000 + (*(end_date + 1) - '0') * 1000000
		+ (*(end_date + 2) - '0') * 100000 + (*(end_date + 3) - '0') * 10000
		+ (*(end_date + 5) - '0') * 1000 + (*(end_date + 6) - '0') * 100
		+ (*(end_date + 8) - '0') * 10 + (*(end_date + 9) - '0');
	/*printf("%s.%s ",start.code1, start.code2);
	printf("%d %d\n", start.datenum, end.datenum);*/
	//���ݶ��벢ת��
	//qsort(use+1, num, sizeof(use[1]), cmpstd2);
	s = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd2);
	while(s==NULL){
		start.datenum++;
		s = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd2);
		if(s==NULL&&e==NULL&&start.datenum==end.datenum){
	//    printf("-1");
	    return;
	    }
	}
	e = (stockinf*)bsearch(q, use+1, num, sizeof(use[1]), cmpstd2);
	while(e==NULL){
		end.datenum--;
		e = (stockinf*)bsearch(q, use+1, num, sizeof(use[1]), cmpstd2);
		if(s==NULL&&e==NULL&&start.datenum==end.datenum){
	//    printf("-1");
	    return;
	    }
	}
	if(s->number<=30) {
		//printf("-1");
		return ;
	}
	for (i = -30; ((s + i)->datenum) <= (e->datenum); i++) {
		if (i == -30) {
			((s + i)->EMA_12) = ((s + i)->close);
			((s + i)->EMA_26) = ((s + i)->close);
			(s + i)->DIF = 0.0;
			(s + i)->DEA = 0.0;
			(s + i)->MACD = 0.0;
		}
		else {
			((s + i)->EMA_12) = ((s + i)->close) * 2 / 13 + ((s + i - 1)->EMA_12) * 11 / 13;
			((s + i)->EMA_26) = ((s + i)->close) * 2 / 27 + ((s + i - 1)->EMA_26) * 25 / 27;
			((s + i)->DIF)=((s + i)->EMA_12) - ((s + i)->EMA_26);
			((s + i)->DEA) = ((s + i - 1)->DEA)* 0.8 + ((s + i)->DIF) * 0.2;
			((s + i)->MACD) = 2 * (((s + i)->DIF) - ((s + i)->DEA));
		}
	}
}
int convert(char p[]){
	int n1;
	return n1=(p[0]-'0')*10000000+(p[1]-'0')*1000000+(p[2]-'0')*100000+(p[3]-'0')*10000+(p[5]-'0')*1000+(p[6]-'0')*100+(p[8]-'0')*10+p[9]-'0';
} 
int compare(const void*p1,const void*p2){
	struct cross *a=(cross*)p1;
	struct cross *b=(cross*)p2;
	if((a->goldencross>b->goldencross)||((a->goldencross==b->goldencross)&&((a->deadcross<b->deadcross))))return -1;
	if((a->goldencross<b->goldencross)||((a->goldencross==b->goldencross)&&((a->deadcross>b->deadcross))))return 1;
	if((a->goldencross==b->goldencross)&&(a->deadcross==b->deadcross)){
		if(strcmp(a->code2,b->code2)>0)return 1;
		if(strcmp(a->code2,b->code2)<0)return -1;
		if(strcmp(a->code2,b->code2)==0){
			if(strcmp(a->code1,b->code1)>0)return 1;
			if(strcmp(a->code1,b->code1)<0)return -1;
		}
	}
}
int MACDTopK(char *start_date, char *end_date,int k){
	int h=1,g=0;
	char code[10];
	int sdate=convert(start_date);
	int edate=convert(end_date);
	mmp=(struct cross*)malloc(n*sizeof(struct cross));
	for(h=1;h<=n;h++){
		if(h==1||strcmp(use[h-1].code1,use[h].code1)!=0||strcmp(use[h-1].code2,use[h].code2)!=0){
			g++;
			strcpy(mmp[g].code1,use[h].code1);
			mmp[g].code1[6]='\0';
			strcpy(mmp[g].code2,use[h].code2);
			mmp[g].code2[2]='\0'; 
			for(int q=0;q<6;q++)
			code[q]=use[h].code1[q];
			code[6]='.';
			code[7]=use[h].code2[0];
			code[8]=use[h].code2[1];
			code[9]='\0';
	     	if(h==1) CalcMacd_without_output(code,start_date,end_date);	
	     	else CalcMacd_without_output_without_qsort(code,start_date,end_date);	
		}
		if(use[h].datenum>=sdate&&use[h].datenum<=edate){
			if(use[h-1].DIF<=use[h-1].DEA&&use[h].DIF>=use[h].DEA)
				mmp[g].goldencross++;
			if(use[h-1].DIF>=use[h-1].DEA&&use[h].DIF<=use[h].DEA)
				mmp[g].deadcross++;	
		}
	}
	int o=g;
		qsort(mmp+1,g,sizeof(mmp[1]),compare);
		for(g=1;g<=k;g++){
			cout<<mmp[g].code1<<"."<<mmp[g].code2<<" "<<start_date<<" "<<end_date<<" "<<mmp[g].goldencross<<" "<<mmp[g].deadcross<<endl;
		}	
	return o;
}
struct data{
	char a1[16];
	char a2[16];
	char a3[16];
};
struct data* hhh;
struct data* hahha;
int _Min(int a,int b,int c) 
{ 
    int min=a; 
    if (b <min) 
    min=b; 
    if(c <min) min=c; 
    return min; 
} 
int ComputeDistance(char s[],char t[]) 
{ 
    int n = strlen(s); 

    int m = strlen(t); 

//int d[][] = new int[n + 1, m + 1]; // matrix 
    int **d = (int **)malloc((n+1) * sizeof(int *)); 
    for(int i=0; i<=n; ++i) 
    { 
        d[i] = (int *)malloc((m+1) * sizeof(int)); 
    } 
// Step 1 
    if (n == 0) 
    { 
        return m; 
    } 

    if (m == 0) 
    { 
        return n; 
    }   

// Step 2 
    for (int i = 0; i <= n; i++) 
    { 
        d[i][0] =i; 
    } 

    for (int j = 0; j <= m; d[0][j] = j++) 
    {  
        d[0][j] =j; 
    } 

// Step 3 
    for (int i = 1; i <= n; i++) 
    { 
//Step 4 
        for (int j = 1; j <= m; j++) 
        {    
// Step 5 
            int cost = (t[j-1] == s[i-1]) ? 0 : 1; 

// Step 6 
            d[i][j] = _Min(d[i-1][j]+1, d[i][j-1]+1,d[i-1][j-1]+cost); 
        } 
    }    
// Step 7 
    return d[n][m]; 
}
int load(void) {
	hahha=(struct data* )malloc(n*sizeof(struct data)); 
	int i,j=0;
	for(i=1;i<=n;i++) {
		if(j==0) {
			strcpy(hahha[j].a1,use[i].code1);strcpy(hahha[j].a2,use[i].code2);strcpy(hahha[j].a3,use[i].code1);
			hahha[j].a1[6]='.';hahha[j].a1[7]='\0';
			strcat(hahha[j].a1,hahha[j].a2);
			j++;continue;
		}
		else {
			if(strcmp(hahha[j-1].a3,use[i].code1)==0&&strcmp(hahha[j-1].a2,use[i].code2)==0) continue;
			else {
				strcpy(hahha[j].a1,use[i].code1);strcpy(hahha[j].a2,use[i].code2);strcpy(hahha[j].a3,use[i].code1);
				hahha[j].a1[6]='.';hahha[j].a1[7]='\0';
				strcat(hahha[j].a1,hahha[j].a2);
				j++; continue;
			}
		}
	}
	return j;
}
int FuzzyMatch (char* query,int thresshoid) {
	int oi,ok;
	qsort(use+1,n,sizeof(use[1]),cmpstd2);
	int m=load();
	int i,j=0;
	for(i=0;i<m;i++) {
		int result= ComputeDistance(query,hahha[i].a1);
		if(result<=thresshoid) {
		    printf("%s\n",hahha[i].a1);
		    j++;
	    }
	}
	return j; 
}
int wherex()  
{  
    CONSOLE_SCREEN_BUFFER_INFO pBuffer;  
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &pBuffer);  
    return (pBuffer.dwCursorPosition.X+1);  
}  
//��ȡ����λ��y  
int wherey()  
{  
    CONSOLE_SCREEN_BUFFER_INFO pBuffer;  
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &pBuffer);  
    return (pBuffer.dwCursorPosition.Y+1);  
}  
//���ù���λ��  
void gotoxy(int x,int y)   
{  
    COORD c;  
    c.X=x-1;  
    c.Y=y-1;  
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);  
}   
double ADR(char *code,char *date);
double MACD(char *code,char *date){
    stockinf key;
	stockinf*pp;
	key.datenum=convert(date);
	for (int i = 0; i < 6; i++) {
		key.code1[i]=*(code + i);	
	}
	key.code1[6]='\0';
	key.code2[0] = *(code + 7);
	key.code2[1] = *(code + 8);
	key.code2[2] = '\0';
	pp=&key;
    qsort(use+1, n, sizeof(use[1]), cmpstd2);
	stockinf*kk = (struct stockinf*)bsearch(pp, use+1, n, sizeof(use[1]), cmpstd2);
	if(kk==NULL){
		return -100;
	}
    int i = 0;
    double rate;
    int wrong=0,correct=0;
    double macd[60];
    int zhangdie[60];
	struct stockinf*k=kk-10;
	//if(strcmp((kk-60)->code1,kk->code1)!=0) return -100;
	if(kk->number<=60) return -100;
	for (i = -50; ((k + i)->datenum) <= ((kk-1)->datenum); i++) {
		if (i == -50) {
			((k + i)->EMA_12) = ((k + i)->close);
			((k + i)->EMA_26) = ((k + i)->close);
			(k + i)->DIF = 0.0;
			(k + i)->DEA = 0.0;
			(k + i)->MACD = 0.0;
		}
		else {
			((k + i)->EMA_12) = ((k+ i)->close) * 2 / 13 + ((k + i - 1)->EMA_12) * 11 / 13;
			((k + i)->EMA_26) = ((k + i)->close) * 2 / 27 + ((k + i - 1)->EMA_26) * 25 / 27;
			((k + i)->DIF)=((k + i)->EMA_12) - ((k + i)->EMA_26);
			((k + i)->DEA) = ((k + i - 1)->DEA)* 0.8 + ((k + i)->DIF) * 0.2;
			((k + i)->MACD) = 2 * (((k + i)->DIF) - ((k + i)->DEA));
	}
		if(i>=-50&&i<10){
		macd[i+50]=(k+i)->DIF-(k + i)->DEA;
		zhangdie[i+50]=(k+i)->close>(k+i)->open;
	}
}
    for(int i=10;i<60;i++){//����׼ȷ�� 
    	double av1=(macd[i-10]+macd[i-9]+macd[i-8]+macd[i-7]+macd[i-6])/5;
	    double av2=(macd[i-5]+macd[i-4]+macd[i-3]+macd[i-2]+macd[i-1])/5;
	if(av1>0&&av2>0){
		if(zhangdie[i]==0)
		correct++;
		else wrong++;
	}
	if(av1>0&&av2<0){
		if(zhangdie[i]!=0)
		correct++;
		else wrong++;
	}
	if(av1<0&&av2>0){
		if(zhangdie[i]==0)
		correct++;
		else wrong++;
	}
	if(av1<0&&av2<0){
		if(zhangdie[i]!=0)
		correct++;
		else wrong++;
	}
	if(av1==0||av2==0){}	
}
    rate=correct*1.0/(wrong+correct)*1.0;
	double av1=(macd[50]+macd[51]+macd[52]+macd[53]+macd[54])/5;
	double av2=(macd[55]+macd[56]+macd[57]+macd[58]+macd[59])/5;
	//ȡ��Ԥ�����ڵ�ǰ���պ�����ǰ���յ�MACD��ֵ��������� 
	qsort(use+1, n, sizeof(use[1]), cmpstd1);
	if(av1>0&&av2>0){
		return -1.0*rate;
	}
	if(av1>0&&av2<0){
		return 0.5*rate;
	}
	if(av1<0&&av2>0){
		return -0.5*rate;
	}
	if(av1<0&&av2<0){
		return 1.0*rate;
	}
	if(av1==0||av2==0){
		return 0;
	}
}

int Comp7(const void*p1,const void*p2);
int Comp7(const void*p1,const void*p2)
{
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
		if(a->datenum>b->datenum) return 1;
	    else if(a->datenum<b->datenum) return -1;
}
double judge(char *date, char *code1, char *code2) 
{
	int k;
	int datenum1; 
	struct stockinf select[8000];
	int i=0,j=0,whether=0;
	datenum1=(date[0]-'0')*10000000+(date[1]-'0')*1000000+(date[2]-'0')*100000+(date[3]-'0')*10000+(date[5]-'0')*1000+(date[6]-'0')*100+(date[8]-'0')*10+(date[9]-'0');
	for(i=1;i<=num;i++)
	{
		if(strncmp(use[i].code1,code1,6)==0&&strncmp(use[i].code2,code2,2)==0)
		{
			select[j]=use[i];
			j++;
		}
	}
	qsort(select,j,sizeof(select[1]),Comp7);
	for(k=1;k<j;k++)
	{
		if(datenum1==select[k].datenum) 
		{
			whether=1;
			break;
		}
	}
	if(whether==0) return -100;
	int l;
	int correspond=0;
	double rate=0;
	for(l=0;l<k-1;l++)
	{
		if(select[l+2].close>select[l+1].close)
		{
		    if(select[l+1].close>select[l].close&&select[l+1].volume>select[l].volume) correspond++;
		    if(select[l+1].close<select[l].close&&select[l+1].volume<select[l].volume) correspond++;
		}
		else if(select[l+2].close<select[l+1].close)
		{
			if(select[l+1].close>select[l].close&&select[l+1].volume<select[l].volume) correspond++;
		    if(select[l+1].close<select[l].close&&select[l+1].volume>select[l].volume) correspond++;
		}
	}
	rate=correspond/double(k-1);
	if(select[k-1].close<=select[k].close&&select[k-1].volume<=select[k].volume||select[k-1].close>=select[k].close&&select[k-2].volume>=select[k-1].volume) return 1*rate; 
	else if(select[k-1].close<=select[k].close&&select[k-1].volume>=select[k].volume||select[k-1].close>=select[k].close&&select[k-2].volume<=select[k-1].volume) return (-1)*rate;
}
int cmpstd4(const void*p1, const void*p2){//��Ʊ�������� 
	struct stockinf *a = (stockinf*)p1;
	struct stockinf *b = (stockinf*)p2;
	if (strcmp(a->code2, b->code2) < 0 || (strcmp(a->code1, b->code1) > 0 && strcmp(a->code2, b->code2) == 0)
		|| (strcmp(a->code2, b->code2) == 0 && strcmp(a->code1, b->code1) == 0 && a->datenum > b->datenum)) {
		return 1;
	}
	else if (a->datenum == b->datenum&&strcmp(a->code2, b->code2) == 0 && strcmp(a->code1, b->code1) == 0)
		return 0;
	else return -1;}
double wave(char *code,char* date){
	int i = 0;
	int updown[60]={0};
	int tmp=0;
	double s=0.0;
	stockinf key;
	stockinf *p = &key;
	stockinf *pr = NULL,*cur=NULL;
	for (i = 0; i < 6; i++) {
		key.code1[i]=*(code + i);
	}
	key.code1[6] ='\0';
	key.code2[0] = *(code + 7);
	key.code2[1] = *(code + 8);
	key.code2[2] = '\0';
	
	key.datenum = (*(date)-'0') * 10000000 + (*(date + 1) - '0') * 1000000 
		+ (*(date + 2) - '0') * 100000 + (*(date + 3) - '0') * 10000
		+ (*(date + 5) - '0') * 1000 + (*(date + 6) - '0') * 100 
		+ (*(date + 8) - '0') * 10 + (*(date + 9) - '0');
	//���ݶ���ת�� 
	qsort(use+1, num, sizeof(use[1]), cmpstd4);
	pr = (stockinf*)bsearch(p, use+1, num, sizeof(use[1]), cmpstd4);
	if(pr==NULL||pr->number<=30) return -100;
	pr=pr-30;
	//if(strcmp((pr-30)->code1,pr->code1)!=0) return -100;
	if(pr-30==NULL) return -100;
	tmp=0;
	for(i=0;(pr->datenum)<key.datenum;i++){
	    if(tmp==1&&((pr->aclose)>((pr+1)->aclose))) s++;
	    if(tmp==0&&((pr->aclose)<((pr+1)->aclose))) s++; //����date֮ǰ30����Ԥ��׼ȷ���� 
	    if(((pr-1)->aclose)<(pr->aclose)&&((pr+1)->aclose)<(pr->aclose)) tmp=1;//���ֲ��� 
	    if(((pr-1)->aclose)>(pr->aclose)&&((pr+1)->aclose)>(pr->aclose)) tmp=0;//���ֲ��� 
		pr++;
	}
	s=s/30;//����Ԥ��׼ȷ�� 
	if(tmp==1) return s*(-1);//�ж�Ԥ���֮ǰΪ���廹�ǲ��� 
	else return s;
}

int main(){
	system("color EC");
	FILE *fp;
	if ((fp = fopen("zi.txt", "r")) == NULL) {
		printf("cannot open infile :%s\n", "zi.txt");
		return -1;
	}
	while (!feof(fp)) {
		char lll[200];
		fgets(lll,200,fp);
		printf("%s",lll);}
	char infile[100];
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
	cout<<"Choose your language:(��ѡ������ʹ�õ�����:)"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEB) ;
	cout<<"English enter e(Ӣ�������� e :)"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEC) ;
	cout<<"Chinese enter c(���������� c :)"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xED) ;
	char command[100];
	cin>>command;
	while(strlen(command)!=1) 
	{   getchar();
		cout<<"Please enter a correct letter.(��������ȷ����ĸ��)"<<endl;
		cin>>command;
	}
	char insane=command[0];
	if(insane=='e') lan=1;
	else if(insane=='c') lan=2;	
	while(lan==0)
	{   SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
		cout<<"Please enter a correct letter.(��������ȷ����ĸ��)"<<endl;
		getchar();
		cin>>command;
		insane=command[0];
		if(insane=='e') lan=1;
	    else if(insane=='c') lan=2;	
	
	}
	if(lan==1) 
	{SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
	cout<<"Welcome to use our product!\n";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xED) ;
	cout<<"Wish you would become a millionaire!\n";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
	cout<<"Please enter the infile name :\n";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
    cin>>infile;
	num = LoadStockData(infile);
	while(num==-1){
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0x4E) ;
		cout<<"Please open a correct file.\n";
		cout<<"Enter the infile name again:";
		cin>>infile;
		num = LoadStockData(infile);
	}
	char a[20];
	char b[20]; 
	int v=0;
	while(1)
	{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE0) ;
	cout<<"The sum of your stock is :"<<num<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEC) ;
	cout<<"If you want to query,please input 'q'"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE2) ;
	cout<<"If you want to query in the way of TopK,please input 't'"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
	cout<<"If you want to calculate elementary index,please input 'c'"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
	cout<<"If you want to calculate macd,please input 'm'"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
	cout<<"If you want to query in the way of macd,please input 'M'"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE6) ;
	cout<<"If you want to do fuzzy matching,please input 'f' "<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEA) ;
	cout<<"you can try this creative functions by input 'k"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE8) ;
	cout<<"If you want to stop the program,please input 's' "<<endl;
	if(v==0) getchar(); 
	v=1;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE9) ;
	cout<<"Please input a character:";
	cin>>command;
	while(strlen(command)!=1) 
	{   getchar();
		cout<<"Please enter a correct letter.(��������ȷ����ĸ��)"<<endl;
		cin>>command;
	}
	char x=command[0];
	switch(x){
		case 'q' :{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE1) ;
			cout<<"Please input the sentence like this:-C followed by a stock code, for instance: -C 000001.SZ;\n";
            cout<<"-d followed by a exact date��for instance��-d 2017-01-03;\n"; 
			cout<<"-o for inquiring the opening;\n";         
            cout<<"-c for inquiring the settlement;\n";
            cout<<"-a for inquiring the adjusted settlement;\n";
            cout<<"-h for inquiring the ceiling price;\n";
            cout<<"-l for inquiring the bottom price;\n";
            cout<<"Enter the sentence:";
            char para_str[100];
            getchar();
            gets(para_str);
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xAC) ;
            cout<<Query(para_str )<<endl;
            break;
		}
		case 't':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE2) ;
			char date[20];
        	char data[20];
        	int k,desc;
            cout<<"Enter date:(for instance: 2017-01-03)";
            cin>>date;
            cout<<"Enter data:(choose one from Volume, Range, AdjClose)";
            cin>>data;
            while(strcmp(data,"Volume")!=0&&strcmp(data,"Range")!=0&&strcmp(data,"AdjClose")!=0){
            	getchar();
            	cout<<"Please input correct command:";
            	cin>>data;
			}
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE6) ;
            cout<<"Enter k and desc:(k represents the number of the stock you want to inquire 1<=k<=10)"<<endl;
            cout<<"For desc, if you enter 1, the top k stock in terms of this index will be output following the order from maximum to minimum"<<endl;
            cout<<"If you enter 0, the bottom k stock in terms of this index will be output following the order from minimum to maximum"<<endl;
			cin>>k>>desc;
		     while((desc!=0&&desc!=1)||!(k<=10&&k>=1)) {
            	getchar();
			    cout<<"Please input correct k and desc:" ;
			    cin>>k>>desc;
				} 
			getchar();
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xAD) ;
            cout<<TopK(date, data, k, desc)<<endl;
            break;
		}
		case 'c':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
			cout<<"Please input the sentence like this:-C followed by a stock code, for instance: -C 000001.SZ;\n";
            cout<<"-d followed by a exact date��for instance��-d 2017-01-03;\n"; 
			cout<<"-o for opening;\n";         
            cout<<"-c for settlement;\n";
            cout<<"-h for ceiling price;\n";
            cout<<"-l for bottom price;\n";
            cout<<"-v for calculating the average;\n";
            cout<<"-s for calculating standard deviations;\n";
            cout<<"Enter the sentence:";
            char para_str[100];
            getchar();
            gets(para_str);
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xAD) ;
            Calculate(para_str);
            break;
		}
		case 'm':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
		    cout<<"Please input the code:";
		    char code[10];
	        char start_date[11];
	        char end_date[11];
	        cin>>code;
		    cout<<"Please input the start date:";
	    	cin>>start_date;
	    	cout<<"Please input the end date:";
	    	cin>>end_date;
	    	getchar();
	    	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA3) ;
		    CalcMacd(code,start_date,end_date);
		    break;
		}
		case 'M':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
			cout<<"start_date��end_date represents the start and end date respectively\n";
			cout<<"k��mean to query the first k records .\n";
	        int k;
	        char start_date[11];
	        char end_date[11];
			cout<<"Please input start_date:";
			cin>>start_date; 
			cout<<"Please input end_date:";
			cin>>end_date;
			cout<<"Please input k:";
			cin>>k;
			getchar();
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA2) ;
			cout<<MACDTopK(start_date,end_date, k)<<endl;
			break;
		}
		case 'f':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE6) ;
			cout<<"Please enter the stock code (# means end)\n";
			cout<<"Please enter the maximum edit distance threshold\n";
			char code[20];
			cin.getline(code,20,'#');
			int th;
			cin>>th;
			getchar();
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA0) ;
			cout<<FuzzyMatch (code,th)<<endl;
			break;
		}
		case 'k':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
			double final=0;
	        char date[11];
         	char data[10];
        	char code[11]={0};
	        char code1[7]={0};
        	char code2[3]={0};
        	int count=0;
            	printf("Please Enter the date:");	
                scanf("%s",date);
                printf("Please Enter the code:");
                scanf("%s",code);
                int datenum=convert(date);
                qsort(use+1, n, sizeof(use[1]), cmpstd1);
                struct stockinf ky;
	            ky.datenum=datenum;
	            for (int i = 0; i < 6; i++) {
		            ky.code1[i]=*(code + i);	
		        }
	            ky.code1[6]='\0';
	            ky.code2[0] = *(code + 7);
	            ky.code2[1] = *(code + 8);
	            ky.code2[2] = '\0';
	            struct stockinf *q=NULL;
				q=(struct stockinf*)bsearch(&ky,use+1,n,sizeof(use[1]),cmpstd1);
                if(q==NULL){
                	getchar();
	            	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
	            	cout<<"Can't find related infomation \n(Please be sure to know the stock information of the previous 60 trading days)\n";
					break; 
				}
				//HideCursor() ;
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
                cout<<"accuracy in the evaluation����\n";
                cout<<"�X�T�T�T�T�T�T�T�T�T�T�["<<endl<<"�U";
				int x=wherex();
				int y=wherey();
				gotoxy(x+20,y);
				cout<<"�U"<<endl;
				cout<<"�^�T�T�T�T�T�T�T�T�T�T�a";
				x=wherex();
				y=wherey();
				gotoxy(x-22,y-1);
				struct stockinf ly;
                struct stockinf *pop;
                pop=q+1;
                strcpy(ly.code1,pop->code1);
                strcpy(ly.code2,pop->code2);
				ly.datenum=datenum;
				int correct=0,wrong=0;
				int ppp=1;
                while(q->datenum==datenum&&count<10){
                char code[20];
                strcpy(code,q->code1);
                code[6]='.'; 
                strcat(code,q->code2);
                double a=judge(date,q->code1,q->code2);
                double b=wave(code,date);
                double c=ADR(code,date);
                double d=MACD(code,date);
                if(a==-100||b==-100||c==-100||d==-100){
                	getchar();
	            	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
	            	cout<<"\n\nCannot predict\n";
	            	ppp=0;
					break; 
				}
                final=a+b+c+d;
                if(final*(q->close-q->open)>0) correct++;
				else wrong++;
				q++;
				count++;
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEC) ;
				cout<<"��"; 
				}
				if(ppp==0)
				break;
				cout<<endl<<endl;
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
				double hr=correct*1.0/(correct+wrong)*1.0;
				cout<<"Overall accuracy:"<< hr*100<<"%"<<endl;
                strncpy(code1,code,6);
                strncpy(code2,code+7,2);
                double a=judge(date,code1,code2);
                double b=wave(code,date);
                double c=ADR(code,date);
                double d=MACD(code,date);
                if(final<0){
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA2) ;
				 printf("The stock is going to fall today\n");}
                else {SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
				printf("The stock is going up today\n");}
                q=(struct stockinf*)bsearch(&ky,use+1,n,sizeof(use[1]),cmpstd1);
                if(final*(q->close-q->open)>0) cout<<"projected correctly\n";
				else cout<<"projected wrongly\n";
				getchar();
                break;
	    }
		case 's' : {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE9) ;
			cout<<"Wish you would enjoy your time with stock!";
		    return 0;
	    }
	    default :{
	    	cout<<"Please enter a correct letter:\n"; 
			break;
		}
    }
	}
}
else if(lan==2)
{SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE2) ;
	cout<<"��ӭ�������ǵ�ϵͳ��\n";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
	cout<<"ϣ������Դ������\n";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE9) ;
	cout<<"�������ļ���:\n";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
    cin>>infile;
	num = LoadStockData(infile);
	int v=0;
	while(num==-1){
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0x4E) ;
		cout<<"��������ȷ���ļ���\n";
		cout<<"���ٴ������ļ���\n";
		cin>>infile;
		num = LoadStockData(infile);
	}
	while(1){
	char a[20];
	char b[20]; 
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE0) ;
	cout<<"��Ʊ��Ϣ������Ϊ��"<<num<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE1) ;
	cout<<"��������ѯĳ֧��Ʊ��ĳ�����Ϣ ����q"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEC) ;
	cout<<"��������ѯĳ��ĳָ���topk֧��Ʊ ����t"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
	cout<<"�����������Ʊ���ݵĻ���ͳ��ָ�� ����c"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEA) ;
	cout<<"��������㼼��ָ�� ����m"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEB) ;
	cout<<"������밴����ָ��ɸѡ��Ʊ ����M"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE9) ;
	cout<<"�������ģ��ƥ�� ����f "<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xED) ;
	cout<<"�������Ԥ���Ʊ�ǵ� ����k"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
	cout<<"�˳� ����s"<<endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE2) ;
	if(v==0) getchar(); 
	v=1; 
	cout<<"������һ����ĸ";
	cin>>command;
	while(strlen(command)!=1) 
	{   getchar();
		cout<<"Please enter a correct letter.(��������ȷ����ĸ��)"<<endl;
		cin>>command;
	}
	char x=command[0];
	switch(x){
		case 'q' :{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE1) ;
			cout<<"������һ������ -C�����һ����Ʊ���룬���磺-C 000001.SZ;\n";
            cout<<"-d�����һ����������ڣ����磺-d 2017-01-03;\n"; 
			cout<<"-o ��ʾ��ѯ���̼�;\n";         
            cout<<"-c ��ʾ��ѯ���̼�;\n";
            cout<<"-a ��ʾ��ѯ����������̼�;\n";
            cout<<"-h ��ʾ��ѯ��߼�;\n";
            cout<<"-l ��ʾ��ѯ��ͼ�;\n";
            cout<<"Enter the sentence:";
            char para_str[100];
            getchar();
            gets(para_str);
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
            cout<<Query(para_str )<<endl;
            break;
		}
		case 't':{
			char date[20];
        	char data[20];
        	int k,desc;
        	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE2) ;
            cout<<"�������� ����2017-01-03"<<endl;
            cin>>date;
            cout<<"����ָ�� ����ΪȡֵΪ""Volume""��""Range""��""AdjClose"""<<endl;
            cin>>data;
            while(strcmp(data,"Volume")!=0&&strcmp(data,"Range")!=0&&strcmp(data,"AdjClose")!=0){
            	getchar();
            	cout<<"��������ȷ��ָ��";
            	cin>>data;
			}
            cout<<"������ k �� desc: 1��k��10\n desc: 0����1��0��ʾ��ѯǰk�1��ʾ��ѯ��k�";
            cin>>k>>desc;
            while((desc!=0&&desc!=1)||!(k<=10&&k>=1)) {
            	getchar();
			    cout<<"��������ȷ��k �� descֵ:" ;
			    cin>>k>>desc;} 
			getchar();
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA1) ;
            cout<<TopK(date, data, k, desc)<<endl;
            break;
		}
		case 'c':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
			cout<<"������ -C�����һ����Ʊ���룬���磺-C 000001.SZ;\n";
            cout<<"-d�����һ����������ڣ����磺-d 2017-01-03;\n"; 
			cout<<"-o ��ʾ���̼�;\n";         
            cout<<"-c ��ʾ���̼�;\n";
            cout<<"-h ��ʾ��߼�;\n";
            cout<<"-l ��ʾ��ͼ�;\n";
            cout<<"-v ��ʾ����ƽ��ֵ;\n";
            cout<<"-s ��ʾ�����׼ƫ��;\n";
            cout<<"������";
            char para_str[100];
            getchar();
            gets(para_str);
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA9) ;
            Calculate(para_str);
            break;
		}
		case 'm':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE4) ;
		    cout<<"�������Ʊ����";
		    char code[10];
	        char start_date[11];
	        char end_date[11];
	        cin>>code;
		    cout<<"�����뿪ʼ����";
	    	cin>>start_date;
	    	cout<<"�������������";
	    	cin>>end_date;
	        getchar();
	    	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA1) ;
		    CalcMacd(code,start_date,end_date);
		    break;
		}
		case 'M':{
	        int k;
	        char start_date[11];
	        char end_date[11];
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE5) ;
			cout<<"��������ʼ����\n";
			cin>>start_date; 
			cout<<"��������ֹ����\n";
			cin>>end_date;
			cout<<"������ k: ��ʾ��ѯǰk����¼\n";
			cin>>k;
			getchar();
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA3) ;
			cout<<MACDTopK(start_date,end_date, k)<<endl;
			break;
		}
		case 'f':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE6) ;
			cout<<"�������ѯ�Ĺ�Ʊ��������������༭������ֵ\n";
			char code[20];
			cout<<"���ڹ�Ʊ�������һλ����һ��#��������\n";
			cin.getline(code,20,'#');
			int th;
			cin>>th;
			getchar();
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xAE) ;
			cout<<FuzzyMatch (code,th)<<endl;
			break;
		}
		case 'k':{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEC) ;
			double final=0;
	        char date[11];
         	char data[10];
        	char code[11]={0};
	        char code1[7]={0};
        	char code2[3]={0};
        	int count=0;
            	printf("����������:");	
                scanf("%s",date);
                printf("�������Ʊ����:");
                scanf("%s",code);
                int datenum=convert(date);
                qsort(use+1, n, sizeof(use[1]), cmpstd1);
                struct stockinf ky;
	            ky.datenum=datenum;
	            for (int i = 0; i < 6; i++) {
		            ky.code1[i]=*(code + i);	
		        }
	            ky.code1[6]='\0';
	            ky.code2[0] = *(code + 7);
	            ky.code2[1] = *(code + 8);
	            ky.code2[2] = '\0';
	            struct stockinf *q=NULL;
				q=(struct stockinf*)bsearch(&ky,use+1,n,sizeof(use[1]),cmpstd1);
	            if(q==NULL) {
	            	getchar();
	            	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
	            	cout<<"�Ҳ��������Ϣ\n";
					break; 
				} 
				//HideCursor(); 
                cout<<"׼ȷ�������С���\n";
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE3) ;
                cout<<"�X�T�T�T�T�T�T�T�T�T�T�["<<endl<<"�U";
				int x=wherex();
				int y=wherey();
				gotoxy(x+20,y);
				cout<<"�U"<<endl;
				cout<<"�^�T�T�T�T�T�T�T�T�T�T�a";
				x=wherex();
				y=wherey();
				gotoxy(x-22,y-1);
                struct stockinf ly;
                struct stockinf *pop;
                pop=q+1;
                strcpy(ly.code1,pop->code1);
                strcpy(ly.code2,pop->code2);
				ly.datenum=datenum;
				
				int correct=0,wrong=0;
				int ppp=1;
                while(q->datenum==datenum&&count<10){
                char code[20];
                strcpy(code,q->code1);
                code[6]='.'; 
                strcat(code,q->code2);
                double a=judge(date,q->code1,q->code2);
                double b=wave(code,date);
                double c=ADR(code,date);
                double d=MACD(code,date);
                if(a==-100||b==-100||c==-100||d==-100){
                	getchar();
	            	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
	            	cout<<"\n\n�޷�Ԥ��\n(�뱣֤��֪����ǰ��ʮ�������չ�Ʊ��Ϣ)\n";
	            	ppp=0;
					break; 
				}
                final=a+b+c+d;
                if(final*(q->close-q->open)>0) correct++;
				else wrong++;
				q++;
				count++;
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEC) ;
				cout<<"��"; 
				}
				if(ppp==0) 
				break;
				cout<<endl<<endl;
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xEB) ;
				double hr=correct*1.0/(correct+wrong)*1.0;
				cout<<"����׼ȷ��:"<< hr*100<<"%"<<endl;
                strncpy(code1,code,6);
                strncpy(code2,code+7,2);
                double a=judge(date,code1,code2);
                double b=wave(code,date);
                double c=ADR(code,date);
                double d=MACD(code,date);
                if(final<0){
                	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA2) ;
				 printf("��ֻ��Ʊ����Ҫ��\n");}
                else {SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xA4) ;
				printf("��ֻ��Ʊ����Ҫ��\n");}
                q=(struct stockinf*)bsearch(&ky,use+1,n,sizeof(use[1]),cmpstd1);
                if(final*(q->close-q->open)>0) cout<<"Ԥ����ȷ\n";
				else cout<<"Ԥ�����\n";
				getchar();
                break;
	    }
		case 's' : {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),0xE9) ;
			cout<<"ϣ�������ܳ��ɵ�ʱ�⣡";
		    return 0;
	    }
	    default :{
	    	cout<<"��������ȷ����ĸ��\n"; 
			break;
		}
    }
	}
}
	return 0;
} 
double ADR(char *code,char *date){
	struct stockinf ky;
	int datenum=convert(date);
	ky.datenum=datenum;
	for (int i = 0; i < 6; i++) {
		    ky.code1[i]=*(code + i);	
		}
	    ky.code1[6]='\0';
	    ky.code2[0] = *(code + 7);
	    ky.code2[1] = *(code + 8);
	    ky.code2[2] = '\0';
	qsort(use+1, n, sizeof(use[1]), cmpstd2);        
    struct stockinf *q=(struct stockinf*)bsearch(&ky,use+1,n,sizeof(use[1]),cmpstd2);
    if(q==NULL||q->number<=60) return -100;
    //if(q-use+1<=60){
    //	return -100;
	//}
    if(strcmp((q-60)->code1,q->code1)!=0) {
    	return -100;
	}
	int sdate=(q-60)->datenum;
	qsort(use+1, n, sizeof(use[1]), cmpstd1);
	double hi=0,lo=0;
	int correct=0,wrong=0;
	int g=0;
	int adr[60][3];
	for(int h=1;h<=n;h++){
		if(use[h].datenum>=sdate&&use[h].datenum<=datenum){
			if(use[h].close>use[h].open)
			hi++;
			if(use[h].close<use[h].open)
			lo++;
			if(use[h].datenum!=use[h+1].datenum){
				adr[g][1]=hi;
				adr[g][2]=lo;
				g++;
				adr[g][0]=use[h+1].datenum;
				hi=lo=0;
			}
		}
	}
	g--;
	double nhi=0,nlo=0;
	struct stockinf key;
		key.datenum=datenum;
		for (int i = 0; i < 6; i++) {
		    key.code1[i]=*(code + i);	
		}
	        key.code1[6]='\0';
	        key.code2[0] = *(code + 7);
	        key.code2[1] = *(code + 8);
	        key.code2[2] = '\0';
	    for(int i=10;i<g;i++){
		nhi=0;nlo=0;
	    for(int j=i-10;j<=i;j++){
	    	nhi+=adr[j][1];
	    	nlo+=adr[j][2];
		}
		double tr=nhi/nlo;
		key.datenum=adr[g][0];
		struct stockinf *target=(struct stockinf*)bsearch(&key,use+1,n,sizeof(use[1]),cmpstd1);
		if(tr>1){
		    if(target->open<target->close) correct++;
		    else wrong++;
	    }else{
	    	if(target->close<target->open) correct++;
	    	else wrong++;
		}
	}
	double rate=correct*1.0/(correct+wrong)*1.0;
	nhi=nlo=0;
	for(int k=g-9;k<=g;k++){
		nhi+=adr[g][1];
		nlo+=adr[g][2];
	}
	double r=nhi/nlo;
	if(r>=2.0) return -1*rate;
	if(r<=2.0&&r>=1.5) return -0.5*rate;
	if(r>0.5&&r<1) return 0.25*rate;
	if(r<1.5&&r>1.0) return -0.25*rate;
	if(r>=0.3&&r<0.5) return 0.5*rate;
	if(r<0.3) return 1*rate;
} 
